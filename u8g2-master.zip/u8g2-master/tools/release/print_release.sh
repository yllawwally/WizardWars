# without 'v' prefix
echo -n "2.17.8"
